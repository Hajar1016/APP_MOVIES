

import * as React from 'react';
import Navigator from './routes/drawer'


export default function App() {
  return (
   <Navigator/>
  );




}