import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { globalStyles } from '../styles/globalStyle';

export default function Favoris() {
  return (
    <View style={globalStyles.container}>
      <Text>list des favoris</Text>
      
    </View>
  );
}