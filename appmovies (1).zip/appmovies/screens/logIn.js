import React from 'react';
import { StyleSheet, View, Text,Button,Image} from 'react-native';
//cette page pour login 

export default function Login({navigation, route}) {
    
  return (
    <View >
       <Text> login </Text>
  
     
    </View>
  );
}
